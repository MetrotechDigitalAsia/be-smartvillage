<?php $__env->startSection('content'); ?>

<div class="card card-custom gutter-b">


    <!--begin::Body-->
    <div class="card-body p-0">

        <?php if(session()->has('error')): ?>
            <div class="row pt-8 px-8">
                <div class="col-lg-12">
                    <div class="alert alert-custom alert-notice alert-light-primary fade show" role="alert">
                        <div class="alert-icon"><i class="flaticon-warning"></i></div>
                        <div class="alert-text"><?php echo e(session('error')); ?></div>
                        <div class="alert-close">
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true"><i class="ki ki-close"></i></span>
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        <?php endif; ?>

        <?php if($errors->any()): ?>
            <div class="row pt-8 px-8">
                <div class="col-lg-12">
                    <div class="alert alert-custom alert-notice alert-light-primary fade show" role="alert">
                        <div class="alert-icon"><i class="flaticon-warning"></i></div>
                        <div class="alert-text"><?php echo e($errors); ?></div>
                        <div class="alert-close">
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true"><i class="ki ki-close"></i></span>
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        <?php endif; ?>

        <?php if(session()->has('success')): ?>
            <div class="row pt-8 px-8">
                <div class="col-lg-12">
                    <div class="alert alert-custom alert-notice alert-light-success fade show" role="alert">
                        <div class="alert-icon"><i class="flaticon-warning"></i></div>
                        <div class="alert-text"><?php echo e(session('success')); ?></div>
                        <div class="alert-close">
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true"><i class="ki ki-close"></i></span>
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        <?php endif; ?>

        <!--begin::Wizard-->
        <form action="<?php echo e(empty($staff) ? route('storeStaff') : '/master-data/staff/update/'.$staff->uuid); ?>" enctype="multipart/form-data" method="POST"  >

            <?php echo csrf_field(); ?>

            <div class="wizard wizard-1" id="kt_contact_add" data-wizard-state="step-first" data-wizard-clickable="true">
                <div class="row justify-content-center my-10 px-8 my-lg-15 px-lg-10">
                    <div class="col-xl-12 col-xxl-7">
                        <!--begin::Form Wizard Form-->
                            <!--begin::Form Wizard Step 1-->
                            <div class="pb-5" data-wizard-type="step-content" data-wizard-state="current">
                                <h3 class="mb-10 font-weight-bold text-dark"><?php echo e(empty($staff) ? 'Tambah Data' : 'Ubah Data'); ?></h3>
                                <div class="row">
                                    <div class="col-xl-12">

                                        <div class="form-group row">
                                            <label class="col-xl-3 col-lg-3 col-form-label">File Upload</label>
                                            <div class="col-lg-9 col-xl-6">
                                                <div class="images-preview-div row my-2"></div>
                                                <?php if(!empty($staff)): ?>
                                                    <input type="hidden" name="oldImg" value="<?php echo e($staff->image); ?>">
                                                    <img id="img-old" class="img-fluid my-2 col-6" src="<?php echo e(asset('storage/'.$staff->image)); ?>" >
                                                <?php else: ?>
                                                    <img class="img-preview img-fluid my-2">
                                                <?php endif; ?>
                                                <img class="img-preview img-fluid my-2">
                                                <input type="file" name="image" id="image" onchange="previewImage()" class="form-control-file col-md-9"  <?php if(empty($staff)): ?> required <?php endif; ?> >
                                            </div>
                                        </div>

                                        <div class="form-group row">
                                            <label class="col-xl-3 col-lg-3 col-form-label">Nama Lengkap</label>
                                            <div class="col-lg-9 col-xl-9">
                                                <input class="form-control form-control-lg form-control-solid" type="text" name="fullname" value="<?php echo e($staff['fullname'] ?? ''); ?>" />
                                            </div>
                                        </div>

                                        <div class="form-group row">
                                            <label class="col-form-label col-xl-3 col-lg-3">Posisi</label>
                                            <div class="col-xl-9 col-lg-9">
                                                <select class="form-control form-control-lg form-control-solid" name="id_position">
                                                    <option value="">Pilih Kategori...</option>
                                                    <?php $__currentLoopData = $positions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($item->id); ?>" <?php echo e(!empty($staff) ? $staff['id_position'] == $item->id ? 'selected' : '' : ''); ?>  >
                                                        <?php echo e($item->position_name); ?>

                                                    </option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>
                                        </div>
    
                                        <div class="form-group row">
                                            <label class="col-xl-3 col-lg-3 col-form-label">Tangal Lahir</label>
                                            <div class="col-lg-9 col-xl-9">
                                                <input class="form-control form-control-lg form-control-solid" type="date" name="date_of_birth" value="<?php echo e($staff['date_of_birth'] ?? ''); ?>" />
                                            </div>
                                        </div>

                                        <div class="form-group row">
                                            <label class="col-xl-3 col-lg-3 col-form-label">Telepon</label>
                                            <div class="col-lg-9 col-xl-9">
                                                <input class="form-control form-control-lg form-control-solid" type="text" name="phone" value="<?php echo e($staff['phone'] ?? ''); ?>" />
                                            </div>
                                        </div>

                                        <div class="form-group row">
                                            <label class="col-xl-3 col-lg-3 col-form-label">Email</label>
                                            <div class="col-lg-9 col-xl-9">
                                                <input class="form-control form-control-lg form-control-solid" type="text" name="email" value="<?php echo e($staff['email'] ?? ''); ?>" />
                                            </div>
                                        </div>

                                        <div class="form-group row">
                                            <label class="col-xl-3 col-lg-3 col-form-label">Alamat</label>
                                            <div class="col-lg-9 col-xl-9">
                                                <input class="form-control form-control-lg form-control-solid" type="text" name="address" value="<?php echo e($staff['address'] ?? ''); ?>" />
                                            </div>
                                        </div>

                                        <div class="form-group row">
                                            <label class="col-xl-3 col-lg-3 col-form-label">Status</label>
                                            <div class="col-lg-9 col-xl-9">
                                                <input class="form-control form-control-lg form-control-solid" type="text" name="status" value="<?php echo e($staff['status'] ?? ''); ?>" />
                                            </div>
                                        </div>
    
                                        <div class="form-group row align-items-center">
                                            <label class="col-xl-3 col-lg-3 col-form-label">Jenis Kelamin</label>
                                            <div class="col-lg-9 col-xl-9">
                                                <div class="radio-inline">
                                                    <label class="radio radio-outline radio-success">
                                                        <input type="radio" name="gender" value="pria" <?php echo e(!empty($staff) ? $staff['gender']== 'pria' ? 'checked' : '' : ''); ?> >
                                                        <span></span>
                                                        Pria
                                                    </label>
                                                    <label class="radio radio-outline radio-danger">
                                                        <input type="radio" name="gender" value="wanita" <?php echo e(!empty($staff) ? $staff['gender']== 'wanita' ? 'checked' : '' : ''); ?> />
                                                        <span></span>
                                                        Wanita
                                                    </label>
                                                </div>
                                            </div>
                                        </div>

                                    </div>
                                </div>
                            </div>
                        <!--end::Form Wizard Form-->
                    </div>
                </div>
                <div class="card-footer">
                    <div class="row">
                        <div class="col-lg-6">
                        </div>
                        <div class="col-lg-6  text-lg-right">
                            <button type="submit" class="btn btn-primary mr-2">Simpan</button>
                            <a href="/master-data/staff" class="btn btn-secondary">Batal</a>
                        </div>
                    </div>
                </div>
            </div>
        </form>
        <!--end::Wizard-->
    </div>
    <!--end::Body-->
</div>
    
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
    
    <script>
        
        var QuillEditor = function() {
				var textEditor = function() {
					var quill = new Quill('#kt_quil_1', {
						modules: {
							toolbar: [
								[{
									header: [1, 2, false]
								}],
								['bold', 'italic', 'underline'],
							]
						},
						readOnly: '<?php echo e($readonly ?? false); ?>',
						placeholder: 'Type your text here...',
						theme: 'snow' // or 'bubble'
					});
					quill.on('text-change', function(delta, oldDelta, source) {
						document.querySelector("input[name='description']").value = quill.root.innerHTML;
					});
				}

				var textEditor2 = function() {
					var quill = new Quill('#kt_quil_2', {
						modules: {
							toolbar: [
								[{
									header: [1, 2, false]
								}],
								['bold', 'italic', 'underline'],
							]
						},
						readOnly: '<?php echo e($readonly ?? false); ?>',
						placeholder: 'Type your text here...',
						theme: 'snow' // or 'bubble'
					});
					quill.on('text-change', function(delta, oldDelta, source) {
						document.querySelector("input[name='short_description']").value = quill.root.innerHTML;
					});
				}

				return {
					// public functions
					init: function() {
						textEditor();
						textEditor2();
					}
				};
			}();

			jQuery(document).ready(function() {
				QuillEditor.init();
			});

    </script>


<?php $__env->stopPush(); ?>
<?php echo $__env->make('admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/rahmat-riyadi/Work Area/Laravel/be-smartvillage/resources/views/admin/staff/form.blade.php ENDPATH**/ ?>