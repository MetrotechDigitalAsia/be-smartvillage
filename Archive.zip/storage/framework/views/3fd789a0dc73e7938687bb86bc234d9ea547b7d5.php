<div class="subheader py-2 py-lg-12 subheader-transparent" id="kt_subheader">
    <div class="container d-flex align-items-center justify-content-between flex-wrap flex-sm-nowrap">
        <!--begin::Info-->
        <div class="d-flex align-items-center flex-wrap mr-1">
            <!--begin::Heading-->
            <div class="d-flex flex-column">
                <!--begin::Title-->
                <h2 class="text-white font-weight-bold my-2 mr-5" style="text-transform: capitalize" >
                    <?php if(Route::current()->uri == '/'): ?>
                        Dashboard
                    <?php else: ?>
                        <?php echo e(str_replace('-', ' ',Request::segments()[0])); ?>

                    <?php endif; ?>
                </h2>
                <!--end::Title-->
                <!--begin::Breadcrumb-->
                <div class="d-flex align-items-center font-weight-bold my-2">
                    <!--begin::Item-->
                    <a href="#" class="opacity-75 hover-opacity-100">
                        <i class="flaticon2-shelter text-white icon-1x"></i>
                    </a>
                    <!--end::Item-->

                    <?php $__currentLoopData = Request::segments(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $segment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <span class="label label-dot label-sm bg-white opacity-75 mx-3"></span>
                    <a 
                        href="" 
                        style="text-transform: capitalize;" 
                        class="text-white text-hover-white opacity-75 hover-opacity-100"
                    >
                        <?php echo e(str_replace('-', ' ',$segment)); ?>

                    </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <!--begin::Item-->
                    <!--end::Item-->

                </div>
                <!--end::Breadcrumb-->
            </div>
            <!--end::Heading-->
        </div>
        <!--end::Info-->
    </div>
</div><?php /**PATH /Users/rahmat-riyadi/Work Area/Laravel/be-smartvillage/resources/views/partials/subHeader.blade.php ENDPATH**/ ?>