<?php if($errors->any() || session()->has('error')): ?>
<div class="row pt-8 px-8">
    <div class="col-lg-12">
        <div class="alert alert-custom alert-notice alert-light-primary fade show" role="alert">
            <div class="alert-text">
                <ul class="m-0" >
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>

                <?php echo e(session()->has('error') ?? ''); ?>

            </div>
            <div class="alert-close">
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true"><i class="ki ki-close"></i></span>
                </button>
            </div>
        </div>
    </div>
</div>
<?php endif; ?><?php /**PATH /Users/rahmat-riyadi/Work Area/Laravel/desa-getasan/resources/views/partials/validation-alert.blade.php ENDPATH**/ ?>