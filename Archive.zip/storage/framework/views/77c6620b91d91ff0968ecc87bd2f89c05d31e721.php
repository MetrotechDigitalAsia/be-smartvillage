<?php $__env->startSection('content'); ?>

<div class="card card-custom gutter-b">


    <!--begin::Body-->
    <div class="card-body p-0">

        <?php if(session()->has('error')): ?>
            <div class="row pt-8 px-8">
                <div class="col-lg-12">
                    <div class="alert alert-custom alert-notice alert-light-primary fade show" role="alert">
                        <div class="alert-icon"><i class="flaticon-warning"></i></div>
                        <div class="alert-text"><?php echo e(session('error')); ?></div>
                        <div class="alert-close">
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true"><i class="ki ki-close"></i></span>
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        <?php endif; ?>

        <?php if(session()->has('success')): ?>
            <div class="row pt-8 px-8">
                <div class="col-lg-12">
                    <div class="alert alert-custom alert-notice alert-light-success fade show" role="alert">
                        <div class="alert-icon"><i class="flaticon-warning"></i></div>
                        <div class="alert-text"><?php echo e(session('success')); ?></div>
                        <div class="alert-close">
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true"><i class="ki ki-close"></i></span>
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        <?php endif; ?>

        <!--begin::Wizard-->
        <form action="<?php echo e(empty($destinationPoint) ? route('storeDestinationPoint') : '/tourism-map/point-destinasi/update/'.$destinationPoint->slug); ?>" enctype="multipart/form-data" method="POST"  >

            <?php echo csrf_field(); ?>

            <div class="wizard wizard-1" id="kt_contact_add" data-wizard-state="step-first" data-wizard-clickable="true">
                <div class="row justify-content-center my-10 px-8 my-lg-15 px-lg-10">
                    <div class="col-xl-12 col-xxl-7">
                        <!--begin::Form Wizard Form-->
                            <!--begin::Form Wizard Step 1-->
                            <div class="pb-5" data-wizard-type="step-content" data-wizard-state="current">
                                <h3 class="mb-10 font-weight-bold text-dark"><?php echo e(empty($destinationPoint) ? 'Tambah Data' : 'Ubah Data'); ?></h3>
                                <div class="row">
                                    <div class="col-xl-12">
                                        <div class="form-group row">
                                            <label class="col-xl-3 col-lg-3 col-form-label">Multiple File Upload</label>
                                            <div class="col-lg-9 col-xl-6">
                                                <div class="images-preview-div row my-2"></div>
                                                <?php if(!empty($destinationPoint) && !is_null($destinationPoint->image)): ?>

                                                    <input type="hidden" name="oldImg" value="<?php echo e($destinationPoint->image); ?>">

                                                    <div class="row">
                                                        <?php $__currentLoopData = json_decode($destinationPoint->image); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <img id="img-old" class="img-fluid my-2 col-6" src="<?php echo e(asset('storage/'.$item)); ?>" >
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </div>

                                                <?php else: ?>
                                                    
                                                <?php endif; ?>
                                                <input type="file" name="image[]" id="multiple-image" onchange="previewImages(this)" class="form-control-file col-md-9"  <?php if(empty($destinationPoint)): ?> required <?php endif; ?> multiple >
                                            </div>
                                        </div>

                                        <div class="form-group row">
                                            <label class="col-xl-3 col-lg-3 col-form-label">Nama Destinasi</label>
                                            <div class="col-lg-9 col-xl-9">
                                                <input class="form-control form-control-lg form-control-solid" type="text" name="name" value="<?php echo e($destinationPoint['name'] ?? ''); ?>" />
                                            </div>
                                        </div>

                                        <div class="form-group row">
                                            <label class="col-form-label col-xl-3 col-lg-3">Kategori</label>
                                            <div class="col-xl-9 col-lg-9">
                                                <select class="form-control form-control-lg form-control-solid" name="category">
                                                    <option value="">Pilih Kategori...</option>
                                                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($item); ?>" <?php echo e(!empty($destinationPoint) ? $destinationPoint['category'] == $item ? 'selected' : '' : ''); ?>  >
                                                        <?php echo e($item); ?>

                                                    </option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>
                                        </div>

                                        <div class="form-group row">
                                            <label class="col-xl-3 col-lg-3 col-form-label">Alamat</label>
                                            <div class="col-lg-9 col-xl-9">
                                                <div class="input-group input-group-lg input-group-solid pr-2" >
                                                    <input type="text" class="form-control form-control-lg form-control-solid" id="search_location"  />
                                                    <div class="btn btn-icon btn-sm btn-success get_map">
                                                        <i class="fab fa-sistrix "></i>
                                                    </div>
                                                </div>
                                                <div id="geomap" class="mt-5" style="width: 100%; height: 300px;" ></div>
                                                <input class="form-control form-control-lg form-control-solid mt-5 search_addr" type="text" name="address" value="<?php echo e($destinationPoint['address'] ?? ''); ?>" />
                                            </div>
                                        </div>

                                        <div class="form-group row">
                                            <label class="col-xl-3 col-lg-3 col-form-label">Latitude</label>
                                            <div class="col-lg-9 col-xl-9">
                                                <input class="form-control form-control-lg form-control-solid search_lat" type="text" name="lat" value="<?php echo e($destinationPoint['lat'] ?? ''); ?>" readonly/>
                                            </div>
                                        </div>
                            
                                        <div class="form-group row">
                                            <label class="col-xl-3 col-lg-3 col-form-label">Longtitude</label>
                                            <div class="col-lg-9 col-xl-9">
                                                <input class="form-control form-control-lg form-control-solid search_long" type="text" name="long" value="<?php echo e($destinationPoint['long'] ?? ''); ?>" readonly/>
                                            </div>
                                        </div>
    
                                        <div class="form-group row">
                                            <label class="col-xl-3 col-lg-3 col-form-label">Telepon</label>
                                            <div class="col-lg-9 col-xl-9">
                                                <input class="form-control form-control-lg form-control-solid" type="text" name="phone" value="<?php echo e($destinationPoint['phone'] ?? ''); ?>" />
                                            </div>
                                        </div>

                                        <div class="form-group row">
                                            <label class="col-xl-3 col-lg-3 col-form-label">Website</label>
                                            <div class="col-lg-9 col-xl-9">
                                                <input class="form-control form-control-lg form-control-solid" type="text" name="website" value="<?php echo e($destinationPoint['website'] ?? ''); ?>" />
                                            </div>
                                        </div>
    
                                        <div class="form-group row align-items-center">
                                            <label class="col-xl-3 col-lg-3 col-form-label">Status</label>
                                            <div class="col-lg-9 col-xl-9">
                                                <div class="radio-inline">
                                                    <label class="radio radio-outline radio-success">
                                                        <input type="radio" name="status" value="1" <?php echo e(!empty($destinationPoint) ? $destinationPoint['status']== 1 ? 'checked' : '' : ''); ?> >
                                                        <span></span>
                                                        Active
                                                    </label>
                                                    <label class="radio radio-outline radio-danger">
                                                        <input type="radio" name="status" value="0" <?php echo e(!empty($destinationPoint) ? $destinationPoint['status']== 0 ? 'checked' : '' : ''); ?> />
                                                        <span></span>
                                                        Deactive
                                                    </label>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="form-group row align-items-center">
                                            <label class="col-xl-3 col-lg-3 col-form-label">Prioritas</label>
                                            <div class="col-lg-9 col-xl-9">
                                                <div class="radio-inline">
                                                    <label class="radio radio-outline radio-success">
                                                        <input type="radio" name="priority" value="1" <?php echo e(!empty($destinationPoint) ? $destinationPoint['priority']== 1 ? 'checked' : '' : ''); ?> >
                                                        <span></span>
                                                        Ya
                                                    </label>
                                                    <label class="radio radio-outline radio-danger">
                                                        <input type="radio" name="priority" value="0" <?php echo e(!empty($destinationPoint) ? $destinationPoint['priority']== 0 ? 'checked' : '' : ''); ?> />
                                                        <span></span>
                                                        Tidak
                                                    </label>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="form-group row">
                                            <label class="col-xl-3 col-lg-3 col-form-label">Deskripsi</label>
                                            <div class="col-lg-9 col-xl-9">
                                                <input type="hidden" name="description" value="<?php echo e($investation['description'] ?? ''); ?>" >
                                                <div id="kt_quil_1" style="height: 325px">
                                                    <?php echo $investation['description'] ?? ''; ?>

                                                </div>
                                            </div>
                                        </div>
    
                                    </div>
                                </div>
                            </div>
                        <!--end::Form Wizard Form-->
                    </div>
                </div>
                <div class="card-footer">
                    <div class="row">
                        <div class="col-lg-6">
                        </div>
                        <div class="col-lg-6  text-lg-right">
                            <button type="submit" class="btn btn-primary mr-2">Simpan</button>
                            <a href="/tourism-map/point-destinasi" class="btn btn-secondary">Batal</a>
                        </div>
                    </div>
                </div>
            </div>
        </form>
        <!--end::Wizard-->
    </div>
    <!--end::Body-->
</div>
    
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
    
    <script>
        
        var QuillEditor = function() {
				var textEditor = function() {
					var quill = new Quill('#kt_quil_1', {
						modules: {
							toolbar: [
								[{
									header: [1, 2, false]
								}],
								['bold', 'italic', 'underline'],
							]
						},
						readOnly: '<?php echo e($readonly ?? false); ?>',
						placeholder: 'Type your text here...',
						theme: 'snow' // or 'bubble'
					});
					quill.on('text-change', function(delta, oldDelta, source) {
						document.querySelector("input[name='description']").value = quill.root.innerHTML;
					});
				}

				var textEditor2 = function() {
					var quill = new Quill('#kt_quil_2', {
						modules: {
							toolbar: [
								[{
									header: [1, 2, false]
								}],
								['bold', 'italic', 'underline'],
							]
						},
						readOnly: '<?php echo e($readonly ?? false); ?>',
						placeholder: 'Type your text here...',
						theme: 'snow' // or 'bubble'
					});
					quill.on('text-change', function(delta, oldDelta, source) {
						document.querySelector("input[name='short_description']").value = quill.root.innerHTML;
					});
				}

				return {
					// public functions
					init: function() {
						textEditor();
						textEditor2();
					}
				};
			}();

			jQuery(document).ready(function() {
				QuillEditor.init();
			});

    </script>


<?php $__env->stopPush(); ?>
<?php echo $__env->make('admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u1571641/public_html/cms/resources/views/admin/destinationPoint/form.blade.php ENDPATH**/ ?>