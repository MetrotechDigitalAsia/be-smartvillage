<?php $__env->startSection('content'); ?>


<?php if(session()->has('success')): ?>
    <div class="alert alert-success" role="alert">
        <?php echo e(session('success')); ?>

    </div>
<?php endif; ?>  

<form action="<?php echo e(empty($admin) ? route('storeAdmin') : url('/master-data/admin/update/'.$admin->uuid)); ?>" method="post">

    <?php echo csrf_field(); ?>

<div class="card card-custom">
    <!--begin::Header-->
    <div class="card-header py-3">
        <div class="card-title align-items-center flex-row ">
            <h3 class="card-label font-weight-bolder text-dark"><?php echo e(empty($admin) ? 'Tambah Admin' : 'Ubah Admin'); ?></h3>
        </div>
        <div class="card-toolbar">
            <button type="submit" class="btn btn-success mr-2">Simpan</button>
            <a href="/master-data/admin" class="btn btn-secondary">Batal</a>
        </div>
    </div>
    <!--end::Header-->
    <!--begin::Form-->
    <div class="card-body">

        <!--begin::Heading-->
        <!--begin::Form Group-->

        <div class="form-group row">
            <label class="col-xl-3 col-lg-3 col-form-label">Nama Lengkap</label>
            <div class="col-lg-9 col-xl-6">
                <input class="form-control form-control-lg form-control-solid" type="text" name="fullname" value="<?php echo e($admin['fullname'] ?? ''); ?>" />
            </div>
        </div>

        <div class="form-group row">
            <label class="col-xl-3 col-lg-3 col-form-label">Email</label>
            <div class="col-lg-9 col-xl-6">
                <input class="form-control form-control-lg form-control-solid" type="text" name="email" value="<?php echo e($admin['email'] ?? ''); ?>" />
            </div>
        </div>

        <?php if(empty($admin) ?? null): ?>
            <div class="form-group row">
                <label class="col-xl-3 col-lg-3 col-form-label">Kata Sandi</label>
                <div class="col-lg-9 col-xl-6">
                    <input class="form-control form-control-lg form-control-solid" type="text" name="password" value="<?php echo e($admin['password'] ?? ''); ?>" />
                </div>
            </div>

            <div class="form-group row">
                <label class="col-xl-3 col-lg-3 col-form-label">Konfirmasi Kata Sandi</label>
                <div class="col-lg-9 col-xl-6">
                    <input class="form-control form-control-lg form-control-solid" type="text" name="repassword" />
                </div>
            </div>
        <?php endif; ?>

        <div class="form-group row">
            <label class="col-3 col-form-label">Status</label>
            <div class="col-9 col-form-label">
                <div class="radio-inline">
                    <label class="radio radio-outline radio-success">
                        <input <?php echo e(!empty($admin) ? $admin['status']=="Active" ? 'checked' : '' : ''); ?> type="radio" name="status" value="Active" />
                        <span></span>
                        Active
                    </label>
                    <label class="radio radio-outline radio-success">
                        <input <?php echo e(!empty($admin) ? $admin['status']=="Deactive" ? 'checked' : '' : ''); ?>  type="radio" name="status" value="Deactive" />
                        <span></span>
                        Deactive
                    </label>
                </div>
            </div>
        </div>


        <!--begin::Form Group-->
    </div>
    <!--end::Form-->
</div>

</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u1571641/public_html/cms/resources/views/admin/admin/form.blade.php ENDPATH**/ ?>