<div class="scroll pr-7 mr-n7" data-scroll="true" data-height="300" data-mobile-height="200">
    <!--begin::Item-->
    <?php $__currentLoopData = $notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notify): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="d-flex align-items-center flex-wrap mb-5">
            <div class="symbol symbol-50 symbol-light mr-5">
                <span class="symbol-label">
                    <img src="<?php echo e(asset('storage/'. $notify->data['data']['item_image'])); ?>" class="h-50 align-self-center" alt="" />
                </span>
            </div>
            <div class="d-flex flex-column flex-grow-1 mr-2">
                <a href="/informasi-desa/umkm/show/<?php echo e($notify->data['data']['uuid']); ?>" class="font-weight-bolder text-dark-75 text-hover-primary font-size-lg mb-1"><?php echo e($notify->data['data']['item_name']); ?></a>
                <span class="text-muted font-weight-bold"><?php echo e($notify->created_at->diffForHumans()); ?></span>
            </div>
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('delete-notif', ['notifId' => $notify->id])->html();
} elseif ($_instance->childHasBeenRendered($notify->id)) {
    $componentId = $_instance->getRenderedChildComponentId($notify->id);
    $componentTag = $_instance->getRenderedChildComponentTagName($notify->id);
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild($notify->id);
} else {
    $response = \Livewire\Livewire::mount('delete-notif', ['notifId' => $notify->id]);
    $html = $response->html();
    $_instance->logRenderedChild($notify->id, $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <!--end::Item-->
</div><?php /**PATH /Users/rahmat-riyadi/Work Area/Laravel/desa-getasan/resources/views/livewire/notification-items.blade.php ENDPATH**/ ?>