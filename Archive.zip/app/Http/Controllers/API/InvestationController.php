<?php

namespace App\Http\Controllers\API;

use App\Models\Investation;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class InvestationController extends Controller
{
    public function index(){
        $data = Investation::all();
        return ResponseController::create($data, 'success', 'get all blog successfully', 200);
    }
}
