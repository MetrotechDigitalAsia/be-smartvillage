<div>
    <a 
        class="btn btn-sm btn-light font-weight-bolder py-1 my-lg-0 my-2 text-dark-50"
        wire:click="handleClick()"
    >
        telah dibaca {{ $data }}
    </a>
</div>