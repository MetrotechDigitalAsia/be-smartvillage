@extends('admin.persuratan.surat.dashboard')

@section('table')

	@livewire('mail-table')
    
@endsection

