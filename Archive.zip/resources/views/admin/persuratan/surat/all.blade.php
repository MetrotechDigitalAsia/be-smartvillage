@extends('admin.persuratan.surat.dashboard')

@section('table')

	@livewire('all-mail-table')
    
@endsection

