<?php return array (
  'all-mail-table' => 'App\\Http\\Livewire\\AllMailTable',
  'delete-notif' => 'App\\Http\\Livewire\\DeleteNotif',
  'mail-table' => 'App\\Http\\Livewire\\MailTable',
  'notification-items' => 'App\\Http\\Livewire\\NotificationItems',
);