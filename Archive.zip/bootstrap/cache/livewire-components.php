<?php return array (
  'all-mail-table' => 'App\\Http\\Livewire\\AllMailTable',
  'delete-notif' => 'App\\Http\\Livewire\\DeleteNotif',
  'mail-detail' => 'App\\Http\\Livewire\\MailDetail',
  'mail-notification-items' => 'App\\Http\\Livewire\\MailNotificationItems',
  'mail-table' => 'App\\Http\\Livewire\\MailTable',
  'notification-items' => 'App\\Http\\Livewire\\NotificationItems',
);