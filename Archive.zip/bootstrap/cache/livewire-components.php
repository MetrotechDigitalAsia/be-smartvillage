<?php return array (
  'delete-notif' => 'App\\Http\\Livewire\\DeleteNotif',
  'notification-items' => 'App\\Http\\Livewire\\NotificationItems',
);